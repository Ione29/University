import java.util.ArrayList;

public class MiniDeck extends Deck{
    public MiniDeck(){
        cards = new ArrayList<PlayingCard>();

    }
}
